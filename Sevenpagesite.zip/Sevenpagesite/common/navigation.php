<nav>
  <ul>
    <li><a href="index.php">Home</a></li>
    <li><a href="about_us.php">About</a></li>
    <li><a href="services.php">Services</a></li>
    <li><a href="portfolio.php">Portfolio</a></li>
    <li><a href="blog.php">Blog</a></li>
    <li><a href="contact.php">Contact</a></li>
    <li><a href="faq.php">FAQ</a></li>
  </ul>
</nav>