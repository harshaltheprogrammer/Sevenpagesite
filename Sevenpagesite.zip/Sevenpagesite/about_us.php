<?php include 'common/header.php';?>

<?php include 'common/heading.php';?>

<?php include 'common/navigation.php';?>


<main>
  <h2>About Us</h2>
  <p>Welcome to the About Us page. We are a leading software development company that specializes in creating customized software solutions for businesses. With a team of experienced professionals, we leverage the latest technologies to deliver high-quality software products that meet our clients' specific needs. Our comprehensive and client-centric approach, combined with rigorous quality assurance processes, ensures that we develop robust and scalable applications. Whether it's web, mobile, or desktop platforms, we have the expertise to deliver exceptional results. We are committed to customer satisfaction and strive to build long-term relationships by providing excellent service and support.</p>
  <p>At our software development company, we pride ourselves on being at the forefront of innovation. Our team of skilled software engineers and designers are dedicated to creating cutting-edge solutions that address the unique challenges faced by businesses. We believe in a collaborative approach, working closely with our clients throughout the development process to ensure that their vision is translated into reality. </p>
</main>


<?php include 'common/footer.php';?>

