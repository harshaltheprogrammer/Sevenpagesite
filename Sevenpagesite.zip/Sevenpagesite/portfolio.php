<?php include 'common/header.php';?>

<?php include 'common/heading.php';?>

<?php include 'common/navigation.php';?>

<main id="portfolio">
  <h2>Portfolio</h2>
  <p>Welcome to the Portfolio page. Here, we showcase some of our previous work and projects.</p>
  
  <h3>Project 1</h3>
  <img src="img/Project_one.png" alt="Project 1">
  <br>
  <p>This is a description of Project 1. </p>
  <br>
  <h3>Project 2</h3>
  <img src="img/Project_two.jpg" alt="Project 2">
  <br>
  <p>This is a description of Project 2.</p>
  <br>
  
  <h3>Project 3</h3>
  <img src="img/Project_three.jpg" alt="Project 3">
  <br>
  <p>This is a description of Project 3.</p>
  <br>  
  <h3>Project 4</h3>
  <img src="img/Project_four.jpg" alt="Project 4">
<br>
  <p>This is a description of Project 4.</p>
</main>

<?php include 'common/footer.php';?>

