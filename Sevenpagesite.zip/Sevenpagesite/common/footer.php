
<footer>
  <p>&copy; 2023 My Website. All rights reserved.</p>
</footer>

</body>
</html>
