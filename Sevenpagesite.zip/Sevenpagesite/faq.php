<?php include 'common/header.php';?>

<?php include 'common/heading.php';?>

<?php include 'common/navigation.php';?>


<main>
  <h2>Frequently Asked Questions</h2>
  
  <h3>Question 1?</h3>
  <p>Answer to Question 1.</p>
  
  <h3>Question 2?</h3>
  <p>Answer to Question 2.</p>
  
  <h3>Question 3?</h3>
  <p>Answer to Question 3.</p>
  
  <h3>Question 4?</h3>
  <p>Answer to Question 4.</p>
</main>



<?php include 'common/footer.php';?>

