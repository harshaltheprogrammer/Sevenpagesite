<?php include 'common/header.php';?>

<?php include 'common/heading.php';?>

<?php include 'common/navigation.php';?>

<main>
  <h2>Contact Us</h2>
  <p>Welcome to the Contact Us page. You can reach out to us using the following contact information or by filling out the form below.</p>
  
  <h3>Contact Information</h3>
  <p>Email: info@example.com</p>
  <p>Phone: 123-456-7890</p>
  <p>Address: 123 Main Street, City, Country</p>
  
  <h3>Contact Form</h3>
  <form action="#" method="post" id="contact_form">
    <label for="name">Name:</label>
    <input type="text" id="name" name="name" required><br>
    
    <label for="email">Email:</label>
    <input type="email" id="email" name="email" required><br>
    
    <label for="message">Message:</label>
    <textarea id="message" name="message" required></textarea><br>
    
    <input type="submit" value="Submit">
  </form>
</main>


<?php include 'common/footer.php';?>

