<?php include 'common/header.php';?>

<?php include 'common/heading.php';?>

<?php include 'common/navigation.php';?>

<main>
  <h2>Our Services</h2>
  <p>Welcome to the Services page. Here, we provide a list of the services we offer to our clients.</p>
  
  <h3>Custom Software Development</h3>
  <p>Tailored software solutions for your unique business needs.</p>
  
  <h3>Web Application Development</h3>
  <p>Building responsive and scalable web applications.</p>
  
  <h3>Mobile App Development</h3>
  <p>Creating intuitive and feature-rich mobile apps for iOS and Android.</p>
  
  <h3>Software Testing and QA</h3>
  <p>Rigorous testing processes to ensure reliable and bug-free software.</p>
</main>


<?php include 'common/footer.php';?>

