<?php include 'common/header.php';?>

<?php include 'common/heading.php';?>

<?php include 'common/navigation.php';?>

<main>
  <h2>Blog</h2>
  <p>Welcome to the Blog page. Here, we share articles, news, and updates related to our field of interest.</p>
  
  <h3>Article 1</h3>
  <h4>Posted on June 15, 2023</h4>
  <p>This is the content of Article 1.</p>
  
  <h3>Article 2</h3>
  <h4>Posted on June 10, 2023</h4>
  <p>This is the content of Article 2.</p>
  
  <h3>Article 3</h3>
  <h4>Posted on June 5, 2023</h4>
  <p>This is the content of Article 3.</p>
</main>




<?php include 'common/footer.php';?>

