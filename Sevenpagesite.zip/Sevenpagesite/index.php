<?php include 'common/header.php';?>

<?php include 'common/heading.php';?>


<?php include 'common/navigation.php';?>

<main>
  <h2>Welcome to My Website!</h2>
  <p>This is the home page. Feel free to explore the other pages using the navigation menu above.</p>
</main>

<?php include 'common/footer.php';?>

